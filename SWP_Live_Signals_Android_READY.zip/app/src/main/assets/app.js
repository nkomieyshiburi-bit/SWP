const INSTRUMENTS = [
  {pair:"EUR/USD", symbol:"EURUSD=X", tf:"60m", displayTf:"1H"},
  {pair:"GBP/USD", symbol:"GBPUSD=X", tf:"60m", displayTf:"1H"},
  {pair:"USD/JPY", symbol:"JPY=X", tf:"60m", displayTf:"1H"},
  {pair:"AUD/USD", symbol:"AUDUSD=X", tf:"60m", displayTf:"1H"},
  {pair:"USD/CAD", symbol:"CAD=X", tf:"60m", displayTf:"1H"},
  {pair:"XAU/USD", symbol:"GC=F", tf:"60m", displayTf:"1H"}
];

const state = {
  route:"home", detail:null, search:"", alerts:true, onlyHigh:false,
  watchlist:JSON.parse(localStorage.getItem("swpWatchlist")||"[]"),
  signals:[], loading:false, error:"", lastUpdated:null
};

const fmt = (n, pair="") => {
  if (!Number.isFinite(n)) return "—";
  if (pair.includes("JPY")) return n.toFixed(3);
  if (pair.includes("XAU")) return n.toFixed(2);
  return n.toFixed(5);
};
const rr = s => s && Number.isFinite(s.entry-s.sl) ? `1:${(Math.abs(s.tp1-s.entry)/Math.abs(s.entry-s.sl)).toFixed(1)}` : "—";
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}

function ema(values, period){
  if(values.length < period) return null;
  const k=2/(period+1);
  let e=values.slice(0,period).reduce((a,b)=>a+b,0)/period;
  for(let i=period;i<values.length;i++) e=values[i]*k+e*(1-k);
  return e;
}
function rsi(values, period=14){
  if(values.length<=period) return null;
  let gains=0, losses=0;
  for(let i=1;i<=period;i++){const d=values[i]-values[i-1]; if(d>=0) gains+=d; else losses-=d;}
  let avgGain=gains/period, avgLoss=losses/period;
  for(let i=period+1;i<values.length;i++){
    const d=values[i]-values[i-1];
    avgGain=((avgGain*(period-1))+Math.max(d,0))/period;
    avgLoss=((avgLoss*(period-1))+Math.max(-d,0))/period;
  }
  if(avgLoss===0) return 100;
  return 100-(100/(1+avgGain/avgLoss));
}
function atr(candles, period=14){
  if(candles.length<=period) return null;
  const tr=[];
  for(let i=1;i<candles.length;i++){
    const c=candles[i], p=candles[i-1];
    tr.push(Math.max(c.high-c.low,Math.abs(c.high-p.close),Math.abs(c.low-p.close)));
  }
  return tr.slice(-period).reduce((a,b)=>a+b,0)/period;
}
function momentum(values){
  if(values.length<6) return 0;
  const recent=values[values.length-1]-values[values.length-6];
  return recent;
}

async function fetchYahoo(symbol, interval="60m"){
  const ranges = ["5d","5d"];
  let lastErr;
  for(const host of ["query1.finance.yahoo.com","query2.finance.yahoo.com"]){
    try{
      const url=`https://${host}/v8/finance/chart/${encodeURIComponent(symbol)}?range=${ranges[0]}&interval=${interval}&includePrePost=false&events=div%2Csplits`;
      const res=await fetch(url,{cache:"no-store"});
      if(!res.ok) throw new Error(`Market feed HTTP ${res.status}`);
      const json=await res.json();
      const result=json?.chart?.result?.[0];
      if(!result) throw new Error(json?.chart?.error?.description||"No market data returned");
      const q=result.indicators?.quote?.[0];
      const timestamps=result.timestamp||[];
      const candles=[];
      timestamps.forEach((ts,i)=>{
        const o=q?.open?.[i], h=q?.high?.[i], l=q?.low?.[i], c=q?.close?.[i];
        if([o,h,l,c].every(Number.isFinite)) candles.push({time:ts*1000,open:o,high:h,low:l,close:c});
      });
      if(candles.length<55) throw new Error("Not enough candles for analysis");
      return {candles, price:result.meta?.regularMarketPrice||candles[candles.length-1].close, currency:result.meta?.currency||""};
    }catch(e){ lastErr=e; }
  }
  throw lastErr||new Error("Market feed unavailable");
}

function analyzeInstrument(inst, data){
  const closes=data.candles.map(c=>c.close);
  const e20=ema(closes,20), e50=ema(closes,50), r=rsi(closes,14), a=atr(data.candles,14), m=momentum(closes);
  const price=data.price;
  const bullish=e20>e50 && price>e20 && r>=52 && r<=72 && m>0;
  const bearish=e20<e50 && price<e20 && r>=28 && r<=48 && m<0;
  let dir="WAIT", score=0;
  if(bullish) dir="BUY";
  if(bearish) dir="SELL";

  const trend=Math.min(30,Math.abs(e20-e50)/(a||1)*10);
  const priceScore=(dir!=="WAIT"?20:Math.min(12,Math.abs(price-e20)/(a||1)*8));
  const rsiScore=dir==="BUY"?Math.max(0,20-Math.abs(62-r)*1.5):dir==="SELL"?Math.max(0,20-Math.abs(38-r)*1.5):Math.max(0,10-Math.abs(50-r)*.5);
  const momScore=Math.min(15,Math.abs(m)/(a||1)*5);
  const structure=(dir!=="WAIT"?15:5);
  score=Math.round(Math.min(99,trend+priceScore+rsiScore+momScore+structure));

  const step=a||Math.abs(price)*0.002;
  const sl=dir==="BUY"?price-step:dir==="SELL"?price+step:null;
  const tp1=dir==="BUY"?price+step:dir==="SELL"?price-step:null;
  const tp2=dir==="BUY"?price+step*2:dir==="SELL"?price-step*2:null;
  const reason=dir==="BUY"?
    `Live 1H trend is bullish: EMA20 is above EMA50, price is above EMA20, RSI is ${r.toFixed(1)}, and recent momentum is positive.`:
    dir==="SELL"?
    `Live 1H trend is bearish: EMA20 is below EMA50, price is below EMA20, RSI is ${r.toFixed(1)}, and recent momentum is negative.`:
    `No clean SWP setup yet. EMA trend, RSI and momentum are not aligned strongly enough for a BUY or SELL.`;

  return {pair:inst.pair,symbol:inst.symbol,tf:inst.displayTf,dir,score,entry:price,tp1,tp2,sl,reason,price,ema20:e20,ema50:e50,rsi:r,atr:a,time:data.candles[data.candles.length-1].time};
}

async function loadLiveSignals(){
  state.loading=true; state.error=""; render();
  const results=[]; const errors=[];
  await Promise.all(INSTRUMENTS.map(async inst=>{
    try{const data=await fetchYahoo(inst.symbol,inst.tf);results.push(analyzeInstrument(inst,data));}
    catch(e){errors.push(`${inst.pair}: ${e.message}`)}
  }));
  state.signals=results.sort((a,b)=>b.score-a.score);
  state.lastUpdated=new Date();
  state.loading=false;
  if(!results.length) state.error="Live market feed is unavailable. Check your internet connection and try again.";
  else if(errors.length) state.error=`Some instruments could not be updated (${errors.length}/${INSTRUMENTS.length}).`;
  render();
}

function signalCard(s, compact=false){
  const live=s.dir!=="WAIT";
  return `<article class="card">
    <div class="signal-head">
      <div><div class="pair">${s.pair}</div><div class="direction ${s.dir.toLowerCase()} ${!live?'wait':''}">${s.dir} ${s.dir==="BUY"?"↑":s.dir==="SELL"?"↓":"•"} <span class="badge">${s.tf}</span></div></div>
      <div class="conf">${s.score}<small>SETUP SCORE</small></div>
    </div>
    <div class="grid4">
      <div>PRICE<b>${fmt(s.price,s.pair)}</b></div><div>TP1<b>${live?fmt(s.tp1,s.pair):"—"}</b></div><div>TP2<b>${live?fmt(s.tp2,s.pair):"—"}</b></div><div>SL<b>${live?fmt(s.sl,s.pair):"—"}</b></div>
    </div>
    <div class="reason"><b>${live?"LIVE SETUP":"WAIT"}</b> · RSI ${s.rsi?.toFixed(1)||"—"} · Updated ${new Date(s.time).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}</div>
    ${compact ? `<div class="btn-row"><button class="dark-btn" onclick="openSignal('${s.pair}')">View Details</button></div>` : `<div class="btn-row"><button class="gold-btn" onclick="openSignal('${s.pair}')">View Signal</button><button class="dark-btn" onclick="addWatch('${s.pair}')">☆ Watchlist</button></div>`}
  </article>`;
}

function statusBar(){
  const updated=state.lastUpdated?state.lastUpdated.toLocaleTimeString([], {hour:"2-digit",minute:"2-digit",second:"2-digit"}):"—";
  return `<div class="card" style="margin-top:10px"><div class="kv"><span>Market feed</span><b style="color:${state.error&& !state.signals.length?'var(--red)':'var(--green)'}">${state.error&& !state.signals.length?'OFFLINE':'CONNECTED'}</b></div><div class="kv"><span>Last update</span><b>${updated}</b></div><p class="reason">Signals are algorithmic analysis of market candles, not guaranteed predictions or broker execution.</p></div>`;
}

function home(){
  const live=state.signals.filter(x=>x.dir!=="WAIT");
  return `<div class="page">
    <section class="hero"><img src="assets/swp-owner.png" alt="SWP"><div class="hero-overlay"></div><div class="hero-copy"><h1>SMART WORK PAYS®</h1><p>Self Made CEO • Eddi Kholofelo Shivuri</p></div></section>
    <div class="metrics"><div class="metric"><strong>${state.loading?'…':live.length}</strong><span>LIVE SETUPS</span></div><div class="metric"><strong>${state.loading?'…':state.signals.length}</strong><span>MARKETS TRACKED</span></div><div class="metric"><strong>${state.lastUpdated?'LIVE':'—'}</strong><span>MARKET FEED</span></div><div class="metric"><strong>1:2</strong><span>TP1 / TP2 TARGET</span></div></div>
    <div class="section-title"><h2>LIVE SIGNALS</h2><button class="link" onclick="navigate('signals')">View All</button></div>
    ${state.loading?`<div class="card"><h3>Connecting to market data…</h3><p class="reason">Fetching fresh candles and calculating the SWP setup engine.</p></div>`:live.length?live.slice(0,3).map(x=>signalCard(x,true)).join(""):`<div class="card"><h3>NO CLEAN SETUP</h3><p class="reason">The engine is online, but it is waiting for the market conditions to align.</p></div>`}
    ${statusBar()}
  </div>`;
}

function signals(){
  let filtered=state.signals.filter(x=>x.pair.toLowerCase().includes(state.search.toLowerCase()));
  if(state.onlyHigh) filtered=filtered.filter(x=>x.score>=70 && x.dir!=="WAIT");
  return `<div class="page"><div class="section-title"><h2>LIVE SIGNAL ENGINE</h2><span class="badge">${state.onlyHigh?"70+ setups":"All markets"}</span></div>
    <input id="search" class="search" placeholder="Search market..." value="${state.search}">
    <div class="btn-row"><button class="gold-btn" onclick="toggleHigh()">${state.onlyHigh?"Show All":"Strong Setups"}</button><button class="dark-btn" onclick="refreshSignals()">↻ Refresh Live Data</button></div>
    ${state.loading?`<div class="card"><h3>UPDATING…</h3><p class="reason">Downloading fresh market candles.</p></div>`:state.error?`<div class="card"><h3>FEED NOTICE</h3><p class="reason">${state.error}</p></div>`:""}
    ${filtered.length?filtered.map(x=>signalCard(x)).join(""):!state.loading?`<div class="card"><h3>NO MATCHING LIVE SETUPS</h3><p class="reason">Try “Show All” to see WAIT conditions too.</p></div>`:""}
    ${statusBar()}
  </div>`;
}

function performance(){return `<div class="page"><div class="section-title"><h2>PERFORMANCE</h2><span class="badge">LIVE TRACKING READY</span></div><div class="card"><div style="font-size:30px;color:var(--gold2);font-weight:900">NO FAKE WIN RATE</div><div class="reason">Live signals are now generated from market data. A real win rate will only be shown after the app records and evaluates completed signals over time.</div></div><div class="card"><h3>SWP principles</h3><p class="reason">Focus • Discipline • Patience • Profit<br><br>PLAN | EXECUTE | WIN | REPEAT</p></div></div>`}
function news(){return `<div class="page"><div class="section-title"><h2>MARKET NEWS</h2></div><div class="card"><h3>News connector</h3><p class="reason">News is separate from the live price engine. We can connect an economic calendar/news feed next.</p></div></div>`}
function profile(){return `<div class="page"><img class="profile-img" src="assets/swp-owner.png" alt="SWP owner"><h2 class="big-title">FOUNDER & OWNER</h2><div class="owner-name">EDDI KHOLOFELO SHIVURI</div><p style="text-align:center;color:var(--gold2)">THE SELF MADE CEO OF SMART WORK PAYS®</p><div class="card"><div class="kv"><span>Market feed</span><b>Yahoo Finance chart feed</b></div><div class="kv"><span>Signal mode</span><b>Algorithmic technical analysis</b></div><div class="kv"><span>Risk mode</span><b>Manual confirmation</b></div></div><div class="section-title"><h2>SETTINGS</h2></div><div class="card"><div class="kv"><span>New signal alerts</span><button class="toggle ${state.alerts?'on':''}" onclick="toggleAlerts()"><i></i></button></div><div class="kv"><span>Strong setups only</span><button class="toggle ${state.onlyHigh?'on':''}" onclick="toggleHigh()"><i></i></button></div><div class="kv"><span>Watchlist</span><b>${state.watchlist.length} markets</b></div></div></div>`}
function detail(pair){
  const s=state.signals.find(x=>x.pair===pair)||state.signals[0];
  if(!s) return `<div class="page"><div class="card"><h3>No live data</h3><p class="reason">Refresh the signal engine first.</p></div></div>`;
  const live=s.dir!=="WAIT";
  return `<div class="page"><button class="dark-btn" onclick="navigate('signals')">← Back</button><div class="section-title"><h2>${s.pair}</h2><div class="direction ${s.dir.toLowerCase()}">${s.dir}</div></div><div class="card"><div class="signal-head"><div><span class="badge">${s.tf} LIVE</span></div><div class="conf">${s.score}<small>SETUP SCORE</small></div></div></div><div class="detail-grid"><div class="detail"><span>CURRENT PRICE</span><b>${fmt(s.price,s.pair)}</b></div><div class="detail"><span>TAKE PROFIT 1</span><b style="color:var(--green)">${live?fmt(s.tp1,s.pair):"—"}</b></div><div class="detail"><span>TAKE PROFIT 2</span><b style="color:var(--green)">${live?fmt(s.tp2,s.pair):"—"}</b></div><div class="detail"><span>STOP LOSS</span><b style="color:var(--red)">${live?fmt(s.sl,s.pair):"—"}</b></div><div class="detail"><span>RISK / REWARD</span><b>${live?rr(s):"—"}</b></div><div class="detail"><span>RSI(14)</span><b>${s.rsi.toFixed(1)}</b></div></div><div class="card"><h3>LIVE ANALYSIS</h3><p class="reason">${s.reason}</p><p class="reason">EMA20: ${fmt(s.ema20,s.pair)} · EMA50: ${fmt(s.ema50,s.pair)} · ATR: ${fmt(s.atr,s.pair)}</p></div><div class="btn-row"><button class="gold-btn" onclick="toast('${live?'Live alert set for ':'No alert: waiting for setup on '}${s.pair}')">♧ Set Alert</button><button class="dark-btn" onclick="addWatch('${s.pair}')">☆ Add to Watchlist</button></div></div>`;
}

function navigate(route){state.route=route;render()}
function openSignal(pair){state.route="detail";state.detail=pair;render()}
function addWatch(pair){if(!state.watchlist.includes(pair))state.watchlist.push(pair);localStorage.setItem("swpWatchlist",JSON.stringify(state.watchlist));toast(pair+" added to watchlist")}
function toggleHigh(){state.onlyHigh=!state.onlyHigh;render()}
function toggleAlerts(){state.alerts=!state.alerts;render()}
async function refreshSignals(){toast("Updating live market data…");await loadLiveSignals()}
function render(){
  const screen=document.getElementById("screen");
  screen.innerHTML=state.route==="home"?home():state.route==="signals"?signals():state.route==="performance"?performance():state.route==="news"?news():state.route==="profile"?profile():detail(state.detail);
  document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.route===state.route));
  const search=document.getElementById("search");
  if(search){search.oninput=e=>{state.search=e.target.value;render();const n=document.getElementById("search");n.focus();n.setSelectionRange(n.value.length,n.value.length)}}
}

document.querySelectorAll(".nav-btn").forEach(b=>b.onclick=()=>navigate(b.dataset.route));
document.getElementById("menuBtn").onclick=()=>document.getElementById("drawer").classList.remove("hidden");
document.getElementById("closeDrawer").onclick=()=>document.getElementById("drawer").classList.add("hidden");
document.getElementById("bellBtn").onclick=()=>toast(state.alerts?"Signal alerts are enabled":"Signal alerts are disabled");
document.querySelector(".drawer").addEventListener("click",e=>{if(e.target.id==="drawer")e.currentTarget.classList.add("hidden")});
document.querySelectorAll(".drawer-card [data-route]").forEach(b=>b.onclick=()=>{document.getElementById("drawer").classList.add("hidden");navigate(b.dataset.route)});
render();
loadLiveSignals();
setInterval(loadLiveSignals, 60000);
