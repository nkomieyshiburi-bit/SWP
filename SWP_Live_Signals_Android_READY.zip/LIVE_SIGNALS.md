# SWP Live Signal Engine

This version replaces the prototype/demo signal table with a live market-data analysis layer.

- Pulls fresh OHLC candles from Yahoo Finance's chart endpoint.
- Tracks EUR/USD, GBP/USD, USD/JPY, AUD/USD and USD/CAD.
- Recalculates every 60 seconds and on manual refresh.
- Uses EMA20/EMA50 trend, RSI(14), ATR(14) and recent momentum.
- Emits BUY, SELL or WAIT rather than inventing a signal.
- Entry is the current feed price; TP1/TP2 and SL are ATR-based.
- The displayed number is a **setup score**, not a probability or guaranteed win rate.

The feed is an unofficial Yahoo Finance chart endpoint, so it can be unavailable or delayed and should not be treated as a broker execution feed. Do not use the signals as a guarantee of profit.
