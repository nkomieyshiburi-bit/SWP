# SWP — Smart Work Pays® Android App

SWP Android project with a live market-data signal engine.

## Live signal engine
- Fetches fresh OHLC candles from Yahoo Finance's chart feed.
- Tracks EUR/USD, GBP/USD, USD/JPY, AUD/USD, USD/CAD and XAU/USD.
- Recalculates every 60 seconds and on manual refresh.
- Uses EMA20/EMA50, RSI(14), ATR(14) and recent momentum.
- Produces BUY, SELL or WAIT setups; it does not invent demo signals.
- Entry uses the current feed price; TP1/TP2 and SL are ATR-based.
- The setup score is a technical score, not a probability or guaranteed win rate.

## GitHub build
The repository workflow can extract `SWP_Android_GitHub_Build.zip`, build the Android debug APK, and upload it as a GitHub Actions artifact.

## Important
The market feed may be delayed/unavailable and is not a broker execution feed. Signals are informational/technical analysis only and are not a guarantee of profit.
