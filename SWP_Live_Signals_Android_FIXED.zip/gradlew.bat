@echo off
setlocal
set GRADLE_VERSION=8.7
set BASE_DIR=%USERPROFILE%\.swp-gradle
set DIST_DIR=%BASE_DIR%\gradle-%GRADLE_VERSION%
set ZIP_FILE=%BASE_DIR%\gradle-%GRADLE_VERSION%-bin.zip
set URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip

if not exist "%DIST_DIR%\bin\gradle.bat" (
  if not exist "%BASE_DIR%" mkdir "%BASE_DIR%"
  powershell -NoProfile -Command "Invoke-WebRequest -Uri '%URL%' -OutFile '%ZIP_FILE%'"
  powershell -NoProfile -Command "Expand-Archive -Force '%ZIP_FILE%' '%BASE_DIR%'"
)

call "%DIST_DIR%\bin\gradle.bat" %*
endlocal
