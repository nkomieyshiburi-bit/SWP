# SWP — Smart Work Pays® Android App

Android project for SWP. It packages the existing SWP interface into a real Android application and includes a GitHub Actions workflow that builds an APK in the cloud.

## Current V1
- SWP black/gold branding
- Founder/owner section
- BUY/SELL demo signals
- Entry, TP1, TP2 and SL
- Confidence score
- Watchlist and signal history UI
- Android app icon
- Cloud APK build workflow

## Important
The current signal dataset is demonstration data. It is not a live 90% accuracy guarantee. Live market data and a validated SWP strategy engine are future integrations.
