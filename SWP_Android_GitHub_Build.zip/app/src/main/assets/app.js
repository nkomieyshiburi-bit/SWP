const pairs = [
  {pair:"EUR/USD", dir:"BUY", confidence:92, tf:"1H", entry:1.08745, tp1:1.09245, tp2:1.09645, sl:1.08245, reason:"Bullish market structure on the 1H timeframe. Liquidity sweep below support followed by strong bullish confirmation."},
  {pair:"GBP/USD", dir:"SELL", confidence:91, tf:"1H", entry:1.26580, tp1:1.25980, tp2:1.25220, sl:1.27180, reason:"Bearish structure with rejection from resistance and downside continuation confirmation."},
  {pair:"USD/JPY", dir:"BUY", confidence:90, tf:"4H", entry:156.245, tp1:157.245, tp2:158.245, sl:155.245, reason:"Higher-timeframe bullish structure with a clean retest and momentum confirmation."},
  {pair:"AUD/USD", dir:"SELL", confidence:89, tf:"30M", entry:.65520, tp1:.65180, tp2:.64890, sl:.65820, reason:"Lower-high formation and bearish displacement after a liquidity grab."},
  {pair:"USD/CAD", dir:"BUY", confidence:88, tf:"1H", entry:1.37210, tp1:1.37710, tp2:1.38120, sl:1.36780, reason:"Demand-zone reaction with bullish break-and-retest confirmation."}
];

const state = {route:"home", search:"", alerts:true, onlyHigh:true, watchlist:JSON.parse(localStorage.getItem("swpWatchlist")||"[]")};

const fmt = n => n < 10 ? n.toFixed(5) : n.toFixed(3);
const rr = s => {
  const risk = Math.abs(s.entry-s.sl), reward = Math.abs(s.tp1-s.entry);
  return "1:"+ (reward/risk).toFixed(1);
};
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}

function signalCard(s, compact=false){
  return `<article class="card">
    <div class="signal-head">
      <div><div class="pair">${s.pair}</div><div class="direction ${s.dir.toLowerCase()}">${s.dir} ${s.dir==="BUY"?"↑":"↓"} <span class="badge">${s.tf}</span></div></div>
      <div class="conf">${s.confidence}%<small>CONFIDENCE</small></div>
    </div>
    <div class="grid4">
      <div>ENTRY<b>${fmt(s.entry)}</b></div><div>TP1<b>${fmt(s.tp1)}</b></div><div>TP2<b>${fmt(s.tp2)}</b></div><div>SL<b>${fmt(s.sl)}</b></div>
    </div>
    ${compact ? "" : `<div class="btn-row"><button class="gold-btn" onclick="openSignal('${s.pair}')">View Signal</button><button class="dark-btn" onclick="addWatch('${s.pair}')">☆ Watchlist</button></div>`}
  </article>`;
}

function home(){
  return `<div class="page">
    <section class="hero">
      <img src="assets/swp-owner.png" alt="Eddi Kholofelo Shivuri — SWP">
      <div class="hero-overlay"></div>
      <div class="hero-copy"><h1>SMART WORK PAYS®</h1><p>Self Made CEO • Eddi Kholofelo Shivuri</p></div>
    </section>
    <div class="metrics">
      <div class="metric"><strong>90%+</strong><span>CONFIDENCE TARGET</span></div>
      <div class="metric"><strong>5</strong><span>ACTIVE SETUPS</span></div>
      <div class="metric"><strong>87%</strong><span>DEMO WIN RATE</span></div>
      <div class="metric"><strong>1:2.5</strong><span>AVG R:R</span></div>
    </div>
    <div class="section-title"><h2>HIGH-CONFIDENCE SIGNALS</h2><button class="link" onclick="navigate('signals')">View All</button></div>
    ${pairs.filter(x=>x.confidence>=90).map(x=>signalCard(x,true)).join("")}
  </div>`;
}

function signals(){
  const filtered=pairs.filter(x=>x.pair.toLowerCase().includes(state.search.toLowerCase()) && (!state.onlyHigh || x.confidence>=90));
  return `<div class="page">
    <div class="section-title"><h2>SWP SIGNAL ENGINE</h2><span class="badge">${state.onlyHigh?"90%+ only":"All setups"}</span></div>
    <input id="search" class="search" placeholder="Search currency pair..." value="${state.search}">
    <div class="btn-row"><button class="gold-btn" onclick="toggleHigh()">${state.onlyHigh?"Show All":"90%+ Only"}</button><button class="dark-btn" onclick="refreshSignals()">↻ Refresh Analysis</button></div>
    ${filtered.length?filtered.map(x=>signalCard(x)).join(""):"<div class='card'>No matching setups.</div>"}
    <div class="card"><b>Important:</b><p class="reason">SWP confidence is an analysis score, not a guarantee of profit. The current build uses demonstration market data; connect a licensed live market-data feed before using real-money trading decisions.</p></div>
  </div>`;
}

function performance(){
  return `<div class="page">
    <div class="section-title"><h2>PERFORMANCE</h2><span class="badge">DEMO TRACKING</span></div>
    <div class="card"><div style="font-size:42px;color:var(--gold2);font-weight:900">87%</div><div class="reason">Illustrative win rate from the prototype dataset — not audited live performance.</div></div>
    <div class="detail-grid">
      <div class="detail"><span>Total signals</span><b>156</b></div><div class="detail"><span>Won</span><b style="color:var(--green)">136</b></div>
      <div class="detail"><span>Lost</span><b style="color:var(--red)">20</b></div><div class="detail"><span>Best pair</span><b>EUR/USD</b></div>
    </div>
    <div class="card"><h3>SWP principles</h3><p class="reason">Focus • Discipline • Patience • Profit<br><br>PLAN | EXECUTE | WIN | REPEAT</p></div>
  </div>`;
}

function news(){return `<div class="page"><div class="section-title"><h2>MARKET NEWS</h2></div><div class="card"><h3>Live news connector</h3><p class="reason">This screen is ready for an economic-calendar/news API. The prototype intentionally does not invent current headlines.</p><button class="gold-btn" onclick="toast('News API connection is the next integration step.')">Connection Status</button></div></div>`}

function profile(){
  return `<div class="page">
    <img class="profile-img" src="assets/swp-owner.png" alt="SWP owner">
    <h2 class="big-title">FOUNDER & OWNER</h2><div class="owner-name">EDDI KHOLOFELO SHIVURI</div>
    <p style="text-align:center;color:var(--gold2)">THE SELF MADE CEO OF SMART WORK PAYS®</p>
    <div class="card"><div class="kv"><span>Brand</span><b>SWP — SMART WORK PAYS®</b></div><div class="kv"><span>Trading focus</span><b>Forex & technical analysis</b></div><div class="kv"><span>Risk mode</span><b>Manual confirmation</b></div></div>
    <div class="section-title"><h2>SETTINGS</h2></div>
    <div class="card">
      <div class="kv"><span>New signal alerts</span><button class="toggle ${state.alerts?'on':''}" onclick="toggleAlerts(this)"><i></i></button></div>
      <div class="kv"><span>Show 90%+ only</span><button class="toggle ${state.onlyHigh?'on':''}" onclick="toggleHigh()"><i></i></button></div>
      <div class="kv"><span>Watchlist</span><b>${state.watchlist.length} pairs</b></div>
    </div>
  </div>`;
}

function detail(pair){
  const s=pairs.find(x=>x.pair===pair)||pairs[0];
  return `<div class="page">
    <button class="dark-btn" onclick="navigate('signals')">← Back</button>
    <div class="section-title"><h2>${s.pair}</h2><div class="direction ${s.dir.toLowerCase()}">${s.dir}</div></div>
    <div class="card"><div class="signal-head"><div><span class="badge">${s.tf} TIMEFRAME</span></div><div class="conf">${s.confidence}%<small>CONFIDENCE</small></div></div></div>
    <div class="detail-grid">
      <div class="detail"><span>ENTRY PRICE</span><b>${fmt(s.entry)}</b></div>
      <div class="detail"><span>TAKE PROFIT 1</span><b style="color:var(--green)">${fmt(s.tp1)}</b></div>
      <div class="detail"><span>TAKE PROFIT 2</span><b style="color:var(--green)">${fmt(s.tp2)}</b></div>
      <div class="detail"><span>STOP LOSS</span><b style="color:var(--red)">${fmt(s.sl)}</b></div>
      <div class="detail"><span>RISK / REWARD</span><b>${rr(s)}</b></div><div class="detail"><span>STATUS</span><b style="color:var(--green)">ACTIVE</b></div>
    </div>
    <div class="card"><h3>REASON FOR THE SIGNAL</h3><p class="reason">${s.reason}</p></div>
    <div class="chart"><svg viewBox="0 0 500 220" preserveAspectRatio="none"><polyline points="0,170 35,150 70,175 105,130 140,145 175,115 210,135 245,90 280,105 315,80 350,98 385,60 420,75 455,42 500,25" fill="none" stroke-width="4" class="line-tp"/></svg></div>
    <div class="btn-row"><button class="gold-btn" onclick="toast('Alert set for '+s.pair)">♧ Set Alert</button><button class="dark-btn" onclick="addWatch('${s.pair}')">☆ Add to Watchlist</button></div>
  </div>`;
}

function navigate(route){state.route=route;render()}
function openSignal(pair){state.route="detail";state.detail=pair;render()}
function addWatch(pair){if(!state.watchlist.includes(pair))state.watchlist.push(pair);localStorage.setItem("swpWatchlist",JSON.stringify(state.watchlist));toast(pair+" added to watchlist")}
function toggleHigh(){state.onlyHigh=!state.onlyHigh;render()}
function toggleAlerts(el){state.alerts=!state.alerts;render()}
function refreshSignals(){toast("SWP analysis refreshed");render()}
function render(){
  const screen=document.getElementById("screen");
  screen.innerHTML = state.route==="home"?home():state.route==="signals"?signals():state.route==="performance"?performance():state.route==="news"?news():state.route==="profile"?profile():detail(state.detail);
  document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.route===state.route));
  const search=document.getElementById("search"); if(search){search.oninput=e=>{state.search=e.target.value;render();const n=document.getElementById("search");n.focus();n.setSelectionRange(n.value.length,n.value.length)}}
}
document.querySelectorAll(".nav-btn").forEach(b=>b.onclick=()=>navigate(b.dataset.route));
document.getElementById("menuBtn").onclick=()=>document.getElementById("drawer").classList.remove("hidden");
document.getElementById("closeDrawer").onclick=()=>document.getElementById("drawer").classList.add("hidden");
document.getElementById("bellBtn").onclick=()=>toast(state.alerts?"Signal alerts are enabled":"Signal alerts are disabled");
document.querySelector(".drawer").addEventListener("click",e=>{if(e.target.id==="drawer")e.currentTarget.classList.add("hidden")});
document.querySelectorAll(".drawer-card [data-route]").forEach(b=>b.onclick=()=>{document.getElementById("drawer").classList.add("hidden");navigate(b.dataset.route)});
render();
